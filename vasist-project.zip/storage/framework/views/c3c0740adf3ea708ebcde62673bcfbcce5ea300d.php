

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Ödeme Sonucu</div>

                <div class="card-body text-center">
                    <?php if($status === 'success'): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle fa-3x mb-3"></i>
                            <h4>Ödeme Başarılı</h4>
                            
                            <?php if(isset($package)): ?>
                                <p>Paket No: <?php echo e($package->contract_number); ?></p>
                                <p>Tutar: <?php echo e(number_format($package->price, 2)); ?> TL</p>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-times-circle fa-3x mb-3"></i>
                            <h4>Ödeme Başarısız</h4>
                            
                        </div>
                    <?php endif; ?>

                    <div class="mt-4">
                        <a href="<?php echo e(route('packages.index')); ?>" class="btn btn-primary">
                            Paketlere Dön
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\workspace\Asist1\asisigit\l_vegaasist.com.tr\vasist-project\resources\views/payment/result.blade.php ENDPATH**/ ?>