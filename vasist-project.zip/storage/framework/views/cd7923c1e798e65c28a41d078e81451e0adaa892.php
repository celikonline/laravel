

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('3D Secure Doğrulama')); ?></div>

                <div class="card-body">
                    <div class="text-center mb-4">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Yükleniyor...</span>
                        </div>
                        <p class="mt-2">Banka doğrulama sayfasına yönlendiriliyorsunuz...</p>
                    </div>

                    <form id="threeDForm" method="POST" action="<?php echo e($formData['action_url']); ?>" class="d-none">
                        <?php $__currentLoopData = $formData['inputs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="hidden" name="<?php echo e($name); ?>" value="<?php echo e($value); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    console.log('3D Secure redirect page loaded');
    console.log('Form action URL:', '<?php echo e($formData['action_url']); ?>');
    
    // Sayfa yüklendiğinde otomatik olarak formu gönder
    document.addEventListener('DOMContentLoaded', function() {
        console.log('Starting 3D Secure redirect...');
        const form = document.getElementById('threeDForm');
        console.log('3D Secure form found:', !!form);
        form.submit();
        console.log('3D Secure form submitted');
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\workspace\Asist1\asisigit\l_vegaasist.com.tr\vasist-project\resources\views/payment/redirect.blade.php ENDPATH**/ ?>