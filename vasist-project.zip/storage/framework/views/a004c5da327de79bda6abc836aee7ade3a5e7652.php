<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['count']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['count']); ?>
<?php foreach (array_filter((['count']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php if($count > 0): ?>
    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
        <?php echo e($count); ?>

        <span class="visually-hidden">okunmamış bildirim</span>
    </span>
<?php endif; ?> <?php /**PATH D:\workspace\Asist1\asisigit\l_vegaasist.com.tr\vasist-project\resources\views/components/notification-badge.blade.php ENDPATH**/ ?>