

<?php $__env->startSection('content'); ?>
<div class="container">
       <!-- İstatistik Kartları -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <h5 class="card-title">Toplam Paket</h5>
                    <h2 class="card-text"><?php echo e($totalPackages); ?></h2>
                    <i class="fas fa-box-open fa-2x position-absolute end-0 bottom-0 mb-3 me-3 opacity-50"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <h5 class="card-title">Aktif Paket</h5>
                    <h2 class="card-text"><?php echo e($activePackages); ?></h2>
                    <i class="fas fa-check-circle fa-2x position-absolute end-0 bottom-0 mb-3 me-3 opacity-50"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <h5 class="card-title">Bekleyen Ödeme</h5>
                    <h2 class="card-text"><?php echo e($pendingPayments); ?></h2>
                    <i class="fas fa-clock fa-2x position-absolute end-0 bottom-0 mb-3 me-3 opacity-50"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-danger text-white">
                <div class="card-body">
                    <h5 class="card-title">Süresi Dolmuş</h5>
                    <h2 class="card-text"><?php echo e($expiredPackages); ?></h2>
                    <i class="fas fa-exclamation-circle fa-2x position-absolute end-0 bottom-0 mb-3 me-3 opacity-50"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="row mb-4">
        <!-- Gelir Grafiği -->
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Aylık Gelir</h5>
                </div>
                <div class="card-body">
                    <canvas id="revenueChart" height="300"></canvas>
                </div>
            </div>
        </div>

        <!-- Son İşlemler -->
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Son İşlemler</h5>
                </div>
                <div class="card-body p-0">
                    <div class="list-group list-group-flush recent-activities">
                        <?php $__currentLoopData = $recentPackages->take(100); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="list-group-item">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1"><?php echo e($package->customer->first_name); ?> <?php echo e($package->customer->last_name); ?></h6>
                                    <small><?php echo e($package->created_at->diffForHumans()); ?></small>
                                </div>
                                <p class="mb-1"><?php echo e($package->servicePackage->name); ?></p>
                                <small><?php echo e(number_format($package->price, 2, ',', '.')); ?> ₺</small>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Son Paketler Tablosu -->
    <div class="card">
        <div class="card-header">
            <h5 class="card-title mb-0">Son Paketler</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Poliçe No</th>
                            <th>Müşteri</th>
                            <th>Paket</th>
                            <th>Tutar</th>
                            <th>Durum</th>
                            <th>Tarih</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $recentPackages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($package->contract_number); ?></td>
                                <td><?php echo e($package->customer->first_name); ?> <?php echo e($package->customer->last_name); ?></td>
                                <td><?php echo e($package->servicePackage->name); ?></td>
                                <td><?php echo e(number_format($package->price, 2, ',', '.')); ?> ₺</td>
                                <td>
                                    <?php if($package->status == 'active'): ?>
                                        <span class="badge bg-success">Aktif</span>
                                    <?php elseif($package->status == 'pending_payment'): ?>
                                        <span class="badge bg-warning">Ödeme Bekliyor</span>
                                    <?php elseif($package->status == 'expired'): ?>
                                        <span class="badge bg-danger">Süresi Dolmuş</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($package->created_at->format('d.m.Y H:i')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('revenueChart').getContext('2d');
    
    const monthlyData = <?php echo json_encode($monthlyRevenue, 15, 512) ?>;
    const labels = monthlyData.map(item => {
        const [year, month] = item.month.split('-');
        return `${month}/${year}`;
    });
    const data = monthlyData.map(item => item.total);

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Aylık Gelir (₺)',
                data: data,
                borderColor: 'rgb(75, 192, 192)',
                tension: 0.1,
                fill: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return new Intl.NumberFormat('tr-TR', {
                                style: 'currency',
                                currency: 'TRY'
                            }).format(value);
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return new Intl.NumberFormat('tr-TR', {
                                style: 'currency',
                                currency: 'TRY'
                            }).format(context.raw);
                        }
                    }
                }
            }
        }
    });
});
</script>
<?php $__env->stopPush(); ?>

<style>
.card {
    position: relative;
    overflow: hidden;
}
.card-body {
    z-index: 1;
}
.card i.fa-2x {
    z-index: 0;
}
.recent-activities {
    max-height: 400px;
    overflow-y: auto;
    scrollbar-width: thin;
}
.recent-activities::-webkit-scrollbar {
    width: 6px;
}
.recent-activities::-webkit-scrollbar-track {
    background: #f1f1f1;
}
.recent-activities::-webkit-scrollbar-thumb {
    background: #888;
    border-radius: 3px;
}
.recent-activities::-webkit-scrollbar-thumb:hover {
    background: #555;
}
.recent-activities .list-group-item:hover {
    background-color: #f8f9fa;
}
</style>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\workspace\Asist1\asisigit\l_vegaasist.com.tr\vasist-project\resources\views/dashboard.blade.php ENDPATH**/ ?>