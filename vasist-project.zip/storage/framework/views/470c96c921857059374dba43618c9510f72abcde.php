

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mb-4">
        <div class="col">
            <h2>Teklif Paket Listesi</h2>
        </div>
        <div class="col-auto">
            <div class="btn-group" role="group">
                <a href="<?php echo e(route('packages.export.excel')); ?>?status=pending_payment" class="btn btn-success">
                    <i class="fas fa-file-excel"></i> Excel
                </a>
                <a href="<?php echo e(route('packages.export.pdf')); ?>?status=pending_payment" class="btn btn-danger">
                    <i class="fas fa-file-pdf"></i> PDF
                </a>
                <a href="<?php echo e(route('packages.export.csv')); ?>?status=pending_payment" class="btn btn-info">
                    <i class="fas fa-file-csv"></i> CSV
                </a>
            </div>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Poliçe No</th>
                            <th>Müşteri</th>
                            <th>Plaka</th>
                            <th>Servis Paketi</th>
                            <th>Ücret</th>
                            <th>Başlangıç</th>
                            <th>Bitiş</th>
                            <th>Durum</th>
                            <th>İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($package->contract_number); ?></td>
                                <td><?php echo e($package->customer_name); ?></td>
                                <td>
                                    <div class="plate-container">
                                        <div class="plate-box">
                                            <span class="plate-text"><?php echo e($package->plate_city); ?> <?php echo e($package->plate_letters); ?> <?php echo e($package->plate_numbers); ?></span>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo e($package->servicePackage->name); ?></td>
                                <td><?php echo e(number_format($package->price, 2, ',', '.')); ?> ₺</td>
                                <td><?php echo e($package->start_date->format('d.m.Y')); ?></td>
                                <td><?php echo e($package->end_date->format('d.m.Y')); ?></td>
                                <td>
                                    <span class="badge bg-warning">Ödeme Bekliyor</span>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="<?php echo e(route('packages.edit', $package->id)); ?>" class="btn btn-sm btn-primary">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="<?php echo e(route('packages.payment', $package->id)); ?>" class="btn btn-sm btn-success">
                                            <i class="fas fa-credit-card"></i>
                                        </a>
                                        <a href="<?php echo e(route('packages.contract-preview', $package->id)); ?>" class="btn btn-sm btn-outline-warning" target="_blank">
                                            <i class="fas fa-file-pdf"></i>
                                        </a>
                                        <a href="<?php echo e(route('packages.receipt-preview', $package->id)); ?>" class="btn btn-sm btn-outline-danger" target="_blank">
                                            <i class="fas fa-file-pdf"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center">Bekleyen teklif paketi bulunamadı.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="d-flex justify-content-end">
                <?php echo e($packages->links()); ?>

            </div>
        </div>
    </div>
</div>

<style>
.plate-container {
    display: inline-block;
}

.plate-box {
    background-image: url('/images/plate-bg.png');
    background-size: contain;
    background-repeat: no-repeat;
    padding: 4px 8px;
    border-radius: 4px;
    min-width: 120px;
    text-align: center;
}

.plate-text {
    font-family: 'Arial', sans-serif;
    font-weight: bold;
    color: #000;
    font-size: 14px;
}

.btn-group .btn {
    margin-right: 2px;
}
</style>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\workspace\Asist1\asisigit\l_vegaasist.com.tr\vasist-project\resources\views/packages/proposals.blade.php ENDPATH**/ ?>